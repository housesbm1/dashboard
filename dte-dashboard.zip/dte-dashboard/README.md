# Dashboard de Facturación DGII

Aplicación frontend para gestión de facturas electrónicas.

## Requisitos

- Node.js 18+
- npm 9+

## Instalación

```bash
git clone https://github.com/tu-usuario/dte-dashboard.git
cd dte-dashboard
npm install